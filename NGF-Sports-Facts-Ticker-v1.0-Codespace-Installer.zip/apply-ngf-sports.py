#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys
root = Path.cwd()
bundle = Path(__file__).resolve().parent

required = [root/'server/routes.ts', root/'client/src/components/Header.tsx', root/'client/src/pages/LandingSimple.tsx', root/'package.json']
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit('Run this from the Coogsnation repository root. Missing: ' + ', '.join(missing))

# Copy additive module files.
for rel in [
    'shared/ngfSportsTypes.ts','client/src/components/LiveScoreTicker.tsx',
    'server/sports/engine.ts','server/sports/reconcile.ts','server/sports/upset.ts','server/sports/ticker.ts','server/sports/scheduler.ts',
    'server/sports/collector.ts','server/sports/devSeed.ts','server/sports/routes.ts','server/sports/store.ts','server/sports/service.ts',
    'server/sports/discovery.ts','server/sports/sourceCatalog.ts','server/sports/adapters/publicScoreboard.ts',
    'server/sports/adapters/ncaa.ts','server/sports/adapters/conference.ts','migrations/0011_ngf_sports_facts.sql',
    'tests/ngf-sports/core.test.ts','tests/ngf-sports/parser.test.ts','scripts/ngf-sports/check.mjs'
]:
    src=bundle/rel; dst=root/rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,dst)

# routes.ts
p=root/'server/routes.ts'; s=p.read_text()
if 'registerSportsHttpRoutes' not in s:
    anchor='import { registerVenueRoutes } from "./venue/routes";'
    repl=anchor+'\nimport { registerSportsHttpRoutes, registerSportsSocketNamespace, startSportsFactsService } from "./sports/routes";\nimport { seedSportsTickerDemo } from "./sports/devSeed";'
    if anchor not in s: raise SystemExit('Could not locate routes import anchor')
    s=s.replace(anchor,repl,1)
if 'registerSportsHttpRoutes(app);' not in s:
    anchor='const sessionMiddleware = await setupAuth(app);'
    if anchor not in s: raise SystemExit('Could not locate setupAuth anchor')
    s=s.replace(anchor, anchor+'\n  registerSportsHttpRoutes(app);',1)
if 'registerSportsSocketNamespace(io.of("/sports"));' not in s:
    anchor='io.engine.use(sessionMiddleware as any);'
    insert='''io.engine.use(sessionMiddleware as any);\n\n  // Public read-only NGF sports events. Collection happens server-side.\n  registerSportsSocketNamespace(io.of("/sports"));\n  seedSportsTickerDemo();\n  void startSportsFactsService().catch((error) => console.error("[SPORTS] Service start failed", error));'''
    if anchor not in s: raise SystemExit('Could not locate Socket.IO anchor')
    s=s.replace(anchor,insert,1)
p.write_text(s)

# Header.tsx
p=root/'client/src/components/Header.tsx'; s=p.read_text()
if 'LiveScoreTicker' not in s:
    anchor='import { FORUM_NAVIGATION, forumCategoryPath } from "@/lib/forumNavigation";'
    if anchor not in s: raise SystemExit('Could not locate Header import anchor')
    s=s.replace(anchor,anchor+'\nimport { LiveScoreTicker } from "@/components/LiveScoreTicker";',1)
if '<LiveScoreTicker />' not in s:
    idx=s.rfind('</header>')
    if idx<0: raise SystemExit('Could not locate Header closing tag')
    s=s[:idx]+'  <LiveScoreTicker />\n    '+s[idx:]
p.write_text(s)

# LandingSimple.tsx (custom nav does not use Header)
p=root/'client/src/pages/LandingSimple.tsx'; s=p.read_text()
if 'LiveScoreTicker' not in s:
    anchor='import { useAuth } from "@/hooks/useAuth";'
    if anchor not in s: raise SystemExit('Could not locate Landing import anchor')
    s=s.replace(anchor,anchor+'\nimport { LiveScoreTicker } from "@/components/LiveScoreTicker";',1)
if '<LiveScoreTicker />' not in s:
    nav_close=s.find('</nav>')
    if nav_close<0: raise SystemExit('Could not locate landing nav closing tag')
    nav_close += len('</nav>')
    s=s[:nav_close]+'\n\n      <LiveScoreTicker />'+s[nav_close:]
p.write_text(s)

# .env.example
p=root/'.env.example'; s=p.read_text() if p.exists() else ''
block='''\n# NGF Sports Facts Engine\nSPORTS_FACTS_ENABLED=true\n# Development-only human-eye ticker demo. Never enable in production.\nSPORTS_TICKER_DEMO=false\n'''
if 'SPORTS_FACTS_ENABLED=' not in s: p.write_text(s.rstrip()+block)

# package.json
p=root/'package.json'; data=json.loads(p.read_text()); scripts=data.setdefault('scripts',{})
scripts.setdefault('sports:check','node scripts/ngf-sports/check.mjs')
p.write_text(json.dumps(data,indent=2)+'\n')

print('[NGF SPORTS] Applied successfully to current checkout')
print('[NGF SPORTS] Next: npm run sports:check && npm run check && npm run build')

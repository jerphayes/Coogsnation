# NGF Sports Facts Engine + Rainbow CFB Ticker — v1.0

This bundle is designed to be applied to the current `Chat-sandbox` checkout of `jerphayes/Coogsnation`.
It does not touch `main` and does not use `drizzle-kit push`.

## What is included

- native React rainbow/multicolor score ticker
- ticker-only upset stop/flash/hold/resume behavior
- public read-only Socket.IO `/sports` namespace
- `/api/sports/ticker` and `/api/sports/health`
- schedule-driven collector: dormant when games are far away, 20s during live action, verifies finals then stops
- NCAA public scoreboard adapter
- Division I conference public-page adapter as independent secondary source
- source health/reliability tracking and freshness-weighted multi-source reconciliation
- rolling NCAA FBS + FCS day-slate discovery (today + tomorrow), populating the NGF team/game registry automatically
- PostgreSQL persistence for teams, games, source observations, and current reconciled state
- additive migration `0011_ngf_sports_facts.sql`
- dev-only visual demo (`SPORTS_TICKER_DEMO=true`) that injects a verified HOU 38 – #4 TEX 35 upset
- module tests and one-command installer

## Safety / database rule

Run the normal migration runner only:

    npm run db:migrate:dev

Do NOT run `drizzle-kit push` / `npm run db:push` as part of this feature. The migration is additive-only and does not alter or drop existing CoogPaws tables.

## Apply in Codespace

1. Check out `Chat-sandbox` and make sure it is current.
2. Unzip this bundle into a temporary directory.
3. From the Coogsnation repository root run:

    python /path/to/bundle/apply-ngf-sports.py
    npm run sports:check
    npm run check
    npm run build
    npm run db:migrate:dev

4. For the human-eye demo, set `SPORTS_TICKER_DEMO=true` in the Codespace environment and run `npm run dev`.
5. Open the site. The ticker appears directly below navigation. After ~8 seconds a top-five upset alert appears only inside the ticker, flashes a few times, holds, and resumes.
6. Set `SPORTS_TICKER_DEMO=false` when finished.

## Create one new full masterbuild

From the repository root, copy `make-masterbuild.sh` there and run:

    bash make-masterbuild.sh MasterBuild-NGF-Sports-Ticker-v1.0.zip

The resulting ZIP is the full current checkout with this feature integrated, excluding `.git`, `node_modules`, `dist`, local `.env` files, logs, and old ZIPs.

## Source behavior

The engine treats upstream pages as replaceable adapters. NCAA is primary; conference pages are secondary verification. If a source changes markup or fails, the core ticker/database/Socket.IO code remains intact and the source's reliability score falls rather than taking down the feature.

The collector extracts factual score/schedule state only. It does not reproduce editorial articles, page design, or graphics.

import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { io } from "socket.io-client";

type TickerItem = {
  gameId: string;
  awayLabel: string;
  awayScore: number | null;
  homeLabel: string;
  homeScore: number | null;
  status: string;
  priority: number;
  accentKey: string;
};

type TickerSnapshot = {
  generatedAt: string;
  games: TickerItem[];
};

type UpsetAlert = {
  gameId: string;
  winner: { abbreviation: string };
  loser: { abbreviation: string; rank?: number | null };
  winnerScore: number;
  loserScore: number;
  severity: "top25" | "top10" | "top5" | "number1";
  holdMs: number;
  flashCount: number;
};

const RAINBOW = [
  ["#c8102e", "#7c3aed"],
  ["#2563eb", "#06b6d4"],
  ["#dc2626", "#f59e0b"],
  ["#9333ea", "#ec4899"],
  ["#059669", "#0ea5e9"],
  ["#d97706", "#dc2626"],
];

function score(value: number | null) {
  return value == null ? "–" : String(value);
}

export function LiveScoreTicker() {
  const [snapshot, setSnapshot] = useState<TickerSnapshot>({ generatedAt: new Date(0).toISOString(), games: [] });
  const [upset, setUpset] = useState<UpsetAlert | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/sports/ticker", { credentials: "same-origin", cache: "no-store" })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error(`Ticker HTTP ${response.status}`)))
      .then((data: TickerSnapshot) => { if (!cancelled) setSnapshot(data); })
      .catch((error) => console.warn("[SPORTS] Initial ticker fetch failed", error));

    const socket = io("/sports", { withCredentials: true });
    socket.on("ticker:snapshot", (data: TickerSnapshot) => setSnapshot(data));
    socket.on("upset:alert", (alert: UpsetAlert) => setUpset(alert));

    return () => {
      cancelled = true;
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!upset) return;
    const timer = window.setTimeout(() => setUpset(null), upset.holdMs);
    return () => window.clearTimeout(timer);
  }, [upset]);

  const loopGames = useMemo(() => snapshot.games.length ? [...snapshot.games, ...snapshot.games] : [], [snapshot.games]);
  if (!snapshot.games.length && !upset) return null;

  return (
    <section className={`ngf-score-ticker ${upset ? "is-upset" : ""}`} aria-label="College football live scores" data-testid="live-score-ticker">
      <style>{`
        .ngf-score-ticker{height:52px;display:flex;overflow:hidden;background:#07101f;color:#fff;border-top:1px solid rgba(255,255,255,.12);border-bottom:1px solid rgba(255,255,255,.2)}
        .ngf-score-badge{height:52px;display:flex;align-items:center;gap:8px;padding:0 15px;background:linear-gradient(135deg,#b91c1c,#dc2626,#f97316);font-size:12px;font-weight:900;letter-spacing:.1em;white-space:nowrap;box-shadow:5px 0 18px rgba(0,0,0,.35);z-index:2}
        .ngf-score-dot{width:8px;height:8px;border-radius:999px;background:#6ee7b7;box-shadow:0 0 10px #6ee7b7}
        .ngf-score-window{overflow:hidden;flex:1}
        .ngf-score-track{height:52px;display:flex;width:max-content;align-items:stretch;animation:ngfScoreScroll 40s linear infinite}
        .ngf-score-game{display:flex;align-items:center;gap:8px;padding:0 20px;border-right:1px solid rgba(255,255,255,.2);font-size:15px;font-weight:900;white-space:nowrap;position:relative;overflow:hidden;isolation:isolate}
        .ngf-score-game:before{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(110deg,var(--ngf-a),var(--ngf-b),transparent 92%);opacity:.58}
        .ngf-score-sep{color:rgba(255,255,255,.55)}
        .ngf-score-status{font-size:11px;background:rgba(255,255,255,.16);padding:4px 8px;border-radius:999px;color:#dff7ff;letter-spacing:.04em}
        .ngf-upset-strip{display:none;width:100%;height:52px;align-items:center;justify-content:center;gap:14px;padding:0 16px;background:linear-gradient(90deg,#7c3aed,#c8102e,#f59e0b,#0891b2);font-weight:950;font-size:17px;animation:ngfUpsetFlash .8s ease-in-out var(--ngf-flashes,3)}
        .ngf-upset-label{color:#fff7ad;letter-spacing:.07em}.ngf-upset-final{font-size:11px;background:rgba(0,0,0,.32);padding:5px 8px;border-radius:7px;letter-spacing:.12em}
        .ngf-score-ticker.is-upset .ngf-score-badge,.ngf-score-ticker.is-upset .ngf-score-window{display:none}.ngf-score-ticker.is-upset .ngf-upset-strip{display:flex}
        @keyframes ngfScoreScroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}
        @keyframes ngfUpsetFlash{0%,100%{opacity:1}35%{opacity:.38}70%{opacity:1}}
        @media(max-width:620px){.ngf-score-badge{padding:0 10px;font-size:10px}.ngf-score-game{padding:0 14px;font-size:13px}.ngf-upset-strip{gap:8px;font-size:14px;padding:0 8px}}
        @media(prefers-reduced-motion:reduce){.ngf-score-track,.ngf-upset-strip{animation:none!important}}
      `}</style>

      {upset ? (
        <div className="ngf-upset-strip" style={{ "--ngf-flashes": String(upset.flashCount) } as CSSProperties} role="status" aria-live="assertive">
          <span className="ngf-upset-label">🚨 UPSET ALERT</span>
          <span>{upset.winner.abbreviation} {upset.winnerScore}</span>
          <span className="ngf-score-sep">—</span>
          <span>{upset.loser.rank ? `#${upset.loser.rank} ` : ""}{upset.loser.abbreviation} {upset.loserScore}</span>
          <span className="ngf-upset-final">FINAL</span>
        </div>
      ) : (
        <>
          <div className="ngf-score-badge"><span className="ngf-score-dot" />CFB LIVE</div>
          <div className="ngf-score-window">
            <div className="ngf-score-track">
              {loopGames.map((game, index) => {
                const colors = RAINBOW[index % RAINBOW.length];
                return (
                  <div key={`${game.gameId}-${index}`} className="ngf-score-game" style={{ "--ngf-a": colors[0], "--ngf-b": colors[1] } as CSSProperties}>
                    <span>{game.awayLabel} {score(game.awayScore)}</span>
                    <span className="ngf-score-sep">•</span>
                    <span>{game.homeLabel} {score(game.homeScore)}</span>
                    <span className="ngf-score-status">{game.status}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </section>
  );
}

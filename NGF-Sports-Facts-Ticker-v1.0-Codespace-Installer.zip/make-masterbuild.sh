#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
OUT="${1:-MasterBuild-NGF-Sports-Ticker.zip}"
rm -f "$OUT"
zip -qr "$OUT" . \
  -x '.git/*' 'node_modules/*' 'dist/*' '.sports-test-dist/*' '*.zip' \
  -x '.env' '.env.*.local' '*.log'
echo "Created $OUT"

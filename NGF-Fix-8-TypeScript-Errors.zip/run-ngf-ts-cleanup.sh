#!/usr/bin/env bash
set -euo pipefail

python3 NGF-Fix-8-TypeScript-Errors.py

echo
echo "[NGF] Running full TypeScript check..."
npm run check

echo
echo "[NGF] Running sports regression checks..."
npm run sports:check

echo
echo "[NGF] Running production build..."
npm run build

echo
echo "[NGF] CLEANUP COMPLETE: check + sports + build all passed."

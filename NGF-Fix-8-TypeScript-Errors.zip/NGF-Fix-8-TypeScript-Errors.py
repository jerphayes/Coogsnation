from pathlib import Path

root = Path.cwd()

# ---------- Fix 1: Coogpaws component stale schema/API type imports ----------
p = root / "client/src/components/CoogpawsApp.tsx"
if not p.exists():
    raise SystemExit("ERROR: Run from the Coogsnation repository root.")

text = p.read_text(encoding="utf-8")
backup = p.with_suffix(".tsx.before-ts-cleanup")
if not backup.exists():
    backup.write_text(text, encoding="utf-8")

text = text.replace(
    'import { insertCoogpawsProfileSchema } from "@shared/schema";\n'
    'import type { CoogpawsProfileResponse, CoogpawsBrowseProfile } from "@shared/api-types";\n',
    ''
)

old = 'const profileSchema = insertCoogpawsProfileSchema.omit({ userId: true });'
new = r'''// Coogpaws database tables intentionally remain outside shared/schema.ts.
// Keep the client form/API contract local so Drizzle will not try to manage
// or drop the existing coogpaws_* production tables.
const profileSchema = z.object({
  bio: z.string(),
  age: z.number().int().min(18).max(99),
  lookingFor: z.string().min(1),
  interests: z.string(),
  photos: z.array(z.string()),
  isActive: z.boolean(),
  locationPreference: z.string().min(1),
  ageRangeMin: z.number().int().min(18).max(99),
  ageRangeMax: z.number().int().min(18).max(99),
});

interface CoogpawsProfileResponse {
  id?: string | number;
  userId: string;
  bio: string | null;
  age: number | null;
  lookingFor: string | null;
  interests: string | null;
  photos: string[] | null;
  isActive: boolean | null;
  locationPreference: string | null;
  ageRangeMin: number | null;
  ageRangeMax: number | null;
  createdAt?: string | null;
  updatedAt?: string | null;
}

interface CoogpawsBrowseProfile extends CoogpawsProfileResponse {
  ownerFirstName?: string | null;
  ownerLastName?: string | null;
  ownerMajorOrDepartment?: string | null;
  ownerGraduationYear?: number | null;
}'''

if old not in text and "interface CoogpawsBrowseProfile extends CoogpawsProfileResponse" not in text:
    raise SystemExit("ERROR: Could not locate the old Coogpaws profile schema line.")
if old in text:
    text = text.replace(old, new)

p.write_text(text, encoding="utf-8")
print("[NGF] Fixed Coogpaws stale schema/API type imports without touching shared/schema.ts.")

# ---------- Fix 2: legacy local catalog provider stale v2 commerce interface ----------
p = root / "server/commerce/providers/localCatalog.ts"
text = p.read_text(encoding="utf-8")
backup = p.with_suffix(".ts.before-ts-cleanup")
if not backup.exists():
    backup.write_text(text, encoding="utf-8")

replacement = r'''import { storage } from "../../storage";

/**
 * Legacy/local database catalog adapter.
 *
 * This is intentionally standalone. The v3 storefront CommerceProvider
 * contract only represents "shopify" and "affiliate". Treating this local
 * database adapter as either provider would mislabel its source.
 */
export interface LocalCatalogCapabilities {
  provider: "local";
  configured: boolean;
  productSearch: boolean;
  productDetails: boolean;
  cartRead: boolean;
  cartMutation: boolean;
  checkoutUrl: boolean;
  note: string;
}

export interface LocalCatalogProduct {
  id: string;
  title: string;
  description: string;
  priceAmount: string;
  currencyCode: string;
  imageUrl?: string;
  productUrl: string;
  availableForSale: boolean;
  provider: "local";
}

export class LocalCatalogProvider {
  readonly name = "local" as const;

  capabilities(): LocalCatalogCapabilities {
    return {
      provider: this.name,
      configured: true,
      productSearch: true,
      productDetails: true,
      cartRead: false,
      cartMutation: false,
      checkoutUrl: false,
      note: "Local CoogsNation catalog is active. AI cart mutations remain disabled until explicit confirmation workflows are accepted.",
    };
  }

  async searchProducts(query: string, limit: number): Promise<LocalCatalogProduct[]> {
    const terms = query.toLowerCase().split(/\W+/).filter((term) => term.length > 2);
    const products = await storage.getProducts(100);
    const ranked = products.map((product) => {
      const haystack = `${product.name} ${product.description || ""} ${product.category || ""}`.toLowerCase();
      const score = terms.reduce((total, term) => total + (haystack.includes(term) ? 1 : 0), 0);
      return { product, score };
    }).filter(({ score }) => score > 0 || terms.length === 0)
      .sort((a, b) => b.score - a.score || a.product.name.localeCompare(b.product.name))
      .slice(0, limit);

    return ranked.map(({ product }) => ({
      id: String(product.id),
      title: product.name,
      description: String(product.description || "").slice(0, 500),
      priceAmount: String(product.price || ""),
      currencyCode: "USD",
      imageUrl: product.imageUrl || undefined,
      productUrl: `/store/product/${product.id}`,
      availableForSale: Boolean(product.isActive) && Number(product.stockQuantity || 0) !== 0,
      provider: this.name,
    }));
  }
}
'''

p.write_text(replacement, encoding="utf-8")
print("[NGF] Fixed legacy local catalog stale commerce type imports.")
print("[NGF] TypeScript cleanup installed.")

import fs from "node:fs";

function read(path) {
  return fs.readFileSync(new URL(`../${path}`, import.meta.url), "utf8");
}

let assertionCount = 0;
function assert(condition, message) {
  assertionCount += 1;
  if (!condition) throw new Error(message);
}

const routes = read("server/routes.ts");
const commerceRoutes = read("server/commerce/routes.ts");
const store = read("client/src/pages/Store.tsx");
const catalog = read("client/src/components/store/StorefrontCatalog.tsx");
const shared = read("shared/commerce.ts");
const seed = read("server/seed.ts");
const migration = read("migrations/0007_provider_neutral_commerce.sql");

assert(!routes.includes("app.post('/api/checkout'"), "Legacy fake checkout route must remain retired");
assert(!routes.includes("app.post('/api/cart'"), "Legacy local cart mutation must remain retired");
assert(!routes.includes("PODManagerService"), "Legacy POD provider manager must remain retired");
assert(commerceRoutes.includes('/api/commerce/storefront'), "Unified storefront endpoint is required");
assert(commerceRoutes.includes('/api/commerce/inquiries'), "High-value inquiry endpoint is required");
assert(store.includes("StorefrontCatalog"), "Store page must use the unified storefront");
assert(catalog.includes("Legacy Jewelry & Class Rings") || read("server/commerce/collections.ts").includes("Legacy Jewelry & Class Rings"), "Legacy jewelry collection is required");
assert(shared.includes('"shopify_product"') && shared.includes('"affiliate_redirect"') && shared.includes('"inquiry"'), "All purchase modes must remain distinct");
assert(!seed.includes("sampleProducts"), "Fake sample merchandise must not be seeded");
assert(migration.includes("commerce_click_events") && migration.includes("commerce_inquiries"), "Revenue tracking tables are required");


/* ---------------------------------------------------------------------------
 * ENVIRONMENT EXAMPLE INTEGRITY
 *
 * .env.example is the only description of what the application can be
 * configured with, and it was previously checked only by asking whether
 * certain strings appeared somewhere in it. That is too weak: a duplicate key
 * satisfies a substring test while silently shadowing the earlier value —
 * which is exactly how SHOPIFY_STOREFRONT_ACCESS_TOKEN came to be declared
 * twice. These checks parse assignments rather than search for strings.
 * ------------------------------------------------------------------------- */
const envExample = read(".env.example");

const assignedKeys = envExample
  .split("\n")
  .map((line) => line.trim())
  .filter((line) => line && !line.startsWith("#"))
  .map((line) => line.split("=")[0].trim())
  .filter(Boolean);

const seenKeys = new Set();
const duplicateKeys = new Set();
for (const key of assignedKeys) {
  if (seenKeys.has(key)) duplicateKeys.add(key);
  seenKeys.add(key);
}
assert(
  duplicateKeys.size === 0,
  `.env.example must not declare a key twice: ${[...duplicateKeys].join(", ")}`,
);

const countKey = (key) =>
  assignedKeys.filter((assigned) => assigned === key).length;

assert(
  countKey("SHOPIFY_STOREFRONT_ACCESS_TOKEN") === 1,
  "SHOPIFY_STOREFRONT_ACCESS_TOKEN must be declared exactly once in .env.example",
);

/* The AI kill switch is read directly by server/ai/config.ts, which throws at
 * startup when it is true without AI_MODEL. It must be documented. */
assert(
  /^AI_ENABLED=false$/m.test(envExample),
  ".env.example must document AI_ENABLED=false",
);

/* Nothing in the application reads COMMERCE_PROVIDER. Documenting a variable
 * that has no effect invites someone to set it and expect something. */
assert(
  countKey("COMMERCE_PROVIDER") === 0,
  "COMMERCE_PROVIDER is unused by the application and must not appear in .env.example",
);

/* ---------------------------------------------------------------------------
 * COMMERCE CAPABILITY CONTRACT
 *
 * Cart and checkout are not implemented in v3.0. The shared interface requires
 * every provider to say so explicitly, and BOTH providers are checked — a test
 * that only covered Shopify would have passed while the affiliate provider
 * stayed silent.
 * ------------------------------------------------------------------------- */
const shopifyProvider = read("server/commerce/providers/shopify.ts");
const affiliateProvider = read("server/commerce/providers/affiliateCatalog.ts");

for (const field of ["cartRead", "cartMutation", "checkoutUrl"]) {
  assert(
    new RegExp(`^\\s*${field}:\\s*boolean;`, "m").test(shared),
    `CommerceProviderCapability must require ${field}`,
  );
  assert(
    new RegExp(`${field}:\\s*false`).test(shopifyProvider),
    `Shopify provider must declare ${field}: false`,
  );
  assert(
    new RegExp(`${field}:\\s*false`).test(affiliateProvider),
    `Affiliate catalog provider must declare ${field}: false`,
  );
}

console.log(`commerce architecture regression: ${assertionCount}/${assertionCount} checks passed`);

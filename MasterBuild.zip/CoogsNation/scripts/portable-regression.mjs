import fs from "node:fs";
import path from "node:path";

const failures = [];
const requireCheck = (condition, message) => { if (!condition) failures.push(message); };
const packageJson = JSON.parse(fs.readFileSync("package.json", "utf8"));
const dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };
const auth = fs.readFileSync("server/auth.ts", "utf8");
const database = fs.readFileSync("server/db.ts", "utf8");
const files = fs.readFileSync("server/fileStorage.ts", "utf8");
const vite = fs.readFileSync("vite.config.ts", "utf8");

requireCheck(fs.existsSync("server/auth.ts"), "portable authentication module is missing");
requireCheck(fs.existsSync("server/fileStorage.ts"), "portable file storage module is missing");
requireCheck(database.includes('from "pg"') && database.includes("drizzle-orm/node-postgres"), "database layer must use standard PostgreSQL");
requireCheck(auth.includes("/api/auth/providers") && auth.includes("login-local") === false, "authentication provider discovery route is missing");
requireCheck(files.includes("UPLOADS_DIR") && files.includes("path.resolve"), "filesystem storage must use a configurable safe root");
requireCheck(!vite.includes("runtimeErrorOverlay") && !vite.includes("cartographer"), "platform-specific Vite plugins remain");

for (const dependency of [
  "openid-client",
  "@google-cloud/storage",
  "@neondatabase/serverless",
  "@uppy/aws-s3",
  "@uppy/core",
  "@uppy/dashboard",
  "@uppy/react"
]) {
  requireCheck(!(dependency in dependencies), `unused vendor-specific dependency remains: ${dependency}`);
}

for (const legacyFile of ["server/objectStorage.ts", "server/objectAcl.ts", "client/src/components/ObjectUploader.tsx"]) {
  requireCheck(!fs.existsSync(legacyFile), `legacy storage file remains: ${legacyFile}`);
}

for (const requiredFile of ["Dockerfile", "docker-compose.yml", ".env.example"]) {
  requireCheck(fs.existsSync(requiredFile), `portable runtime file is missing: ${requiredFile}`);
}

/* ---------------------------------------------------------------------------
 * DATABASE SAFETY
 *
 * This replaced a check that README.md existed. A file-exists assertion on
 * documentation proves nothing about the runtime; these prove the guards that
 * actually stand between a schema push and member data.
 *
 * The hazard being guarded: `drizzle-kit push` reconciles the database to
 * shared/schema.ts and will propose dropping any table the schema no longer
 * declares — including tables no migration ever created. It is safe only on a
 * genuinely empty database.
 * ------------------------------------------------------------------------- */
const packageManifest = JSON.parse(fs.readFileSync("package.json", "utf8"));
const npmScripts = packageManifest.scripts || {};

// 1. Every route to a schema push goes through the guard, never drizzle-kit directly.
for (const scriptName of ["db:bootstrap", "db:push"]) {
  const command = npmScripts[scriptName] || "";
  requireCheck(
    command.includes("db-bootstrap-guard"),
    `${scriptName} must route through scripts/db-bootstrap-guard.mjs, not call drizzle-kit push directly`,
  );
}

// 2. The read-only legacy audit is available.
requireCheck(
  (npmScripts["db:legacy-audit"] || "").includes("legacy-coogpaws-audit"),
  "db:legacy-audit script is missing",
);

// 3. Scripts referenced by package.json actually exist on disk.
for (const referenced of [
  "scripts/db-bootstrap-guard.mjs",
  "scripts/legacy-coogpaws-audit.mjs",
]) {
  requireCheck(fs.existsSync(referenced), `referenced script is missing: ${referenced}`);
}

// 4. Production deployment has no automatic schema-push path at all.
const productionCompose = fs.readFileSync("docker-compose.prod.yml", "utf8");
for (const forbidden of ["db:bootstrap", "db:push", "drizzle-kit push", "DATABASE_BOOTSTRAP"]) {
  requireCheck(
    !productionCompose.includes(forbidden),
    `production Compose must not be able to push schema: found ${forbidden}`,
  );
}

// 5. The legacy audit is read-only in fact, not merely by intention. It runs
//    against a database holding member data, so it is checked statement by
//    statement rather than trusted.
const legacyAudit = fs.readFileSync("scripts/legacy-coogpaws-audit.mjs", "utf8");
requireCheck(
  legacyAudit.includes("BEGIN READ ONLY"),
  "legacy audit must open a read-only transaction",
);
requireCheck(
  legacyAudit.includes("ROLLBACK") && !legacyAudit.includes("COMMIT"),
  "legacy audit must roll back and must never commit",
);
for (const destructive of [
  /\bDROP\s+(TABLE|INDEX|COLUMN|SCHEMA|DATABASE|CONSTRAINT)\b/i,
  /\bTRUNCATE\b/i,
  /\bDELETE\s+FROM\b/i,
  /\bINSERT\s+INTO\b/i,
  /\bUPDATE\s+[a-z_"]+\s+SET\b/i,
  /\bALTER\s+TABLE\b/i,
  /\bGRANT\b|\bREVOKE\b/i,
  /drizzle-kit/i,
]) {
  requireCheck(
    !destructive.test(legacyAudit),
    `legacy audit must contain no destructive or schema-changing SQL: matched ${destructive}`,
  );
}

const sourceExtensions = new Set([".ts", ".tsx", ".js", ".mjs", ".html", ".md", ".json"]);
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (["node_modules", ".git", "dist", "attached_assets"].includes(entry.name)) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(fullPath);
    else if (sourceExtensions.has(path.extname(entry.name))) {
      const text = fs.readFileSync(fullPath, "utf8");
      requireCheck(!text.includes(["127.0.0.1", "1106"].join(":")), `local platform sidecar reference remains in ${fullPath}`);
    }
  }
}
walk(".");

if (failures.length) {
  console.error("Portable foundation checks failed:");
  for (const failure of failures) console.error(` - ${failure}`);
  process.exit(1);
}
console.log("Portable foundation checks passed.");
